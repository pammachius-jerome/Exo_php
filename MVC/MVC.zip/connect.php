<?php
define("BASE","formation");
define("SERVER","localhost:3306");
define("USER","root");
define("PASSWD","");
?>